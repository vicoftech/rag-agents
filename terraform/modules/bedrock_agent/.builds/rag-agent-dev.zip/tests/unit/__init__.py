"""
Tests unitarios del Agente RAG
"""
