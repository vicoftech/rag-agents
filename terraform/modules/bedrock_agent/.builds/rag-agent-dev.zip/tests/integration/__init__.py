"""
Tests de integración del Agente RAG
"""
