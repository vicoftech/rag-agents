"""
Tests manuales/interactivos del Agente RAG
Requieren conexión real a servicios externos (Lambda, Bedrock)
"""
